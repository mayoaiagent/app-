import React from 'react';
import { View, Button, Text, Alert } from 'react-native';
import api from '../api/api';

export default function PurchaseScreen() {
  const handlePayment = async () => {
    try {
      const res = await api.post('/payment/create-checkout-session');
      const url = res.data.url;
      if (url) {
        Alert.alert("Redirect", "Open Stripe checkout", [{ text: "OK" }]);
      }
    } catch (err) {
      Alert.alert("Error", "Failed to start Stripe checkout");
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Buy 5,000 Points for $10</Text>
      <Button title="Pay with Stripe" onPress={handlePayment} />
    </View>
  );
}
