import React, { useContext } from 'react';
import { View, Text, Button } from 'react-native';
import { AuthContext } from '../context/AuthContext';

export default function HomeScreen({ navigation }) {
  const { user, logout } = useContext(AuthContext);

  return (
    <View style={{ padding: 20 }}>
      <Text>Welcome, {user?.email}</Text>
      <Text>You have {user?.points || 0} points</Text>
      <Button title="Buy Points" onPress={() => navigation.navigate('Purchase')} />
      <Button title="Logout" onPress={logout} />
    </View>
  );
}
