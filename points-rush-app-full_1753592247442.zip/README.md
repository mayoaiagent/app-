# Points Rush React Native App (Full)

## ✅ Features
- Login / Signup with JWT auth
- Stripe mobile-ready integration
- Axios connected to Express backend
- Auth context and persistent login

## 🚀 Start
```bash
npm install
npx expo start
```

## 🔗 Change API URL
In `src/api/api.js`, replace the `baseURL` with your backend/ngrok URL.
